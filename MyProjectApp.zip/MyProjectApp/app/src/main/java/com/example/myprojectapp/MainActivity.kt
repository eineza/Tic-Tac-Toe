package com.example.myprojectapp

import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Button
import com.usmaan.tictactoe.R
import android.content.Intent as Intent1

open class MainActivity : AppCompatActivity() {

    lateinit var startNewGameButton: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        startNewGameButton = findViewById(R.id.startNewGameButton)

        startNewGameButton.setOnClickListener {
            val intent = android.content.Intent(this, GameDisplay::class.java)
            startActivity(intent)
        }



        fun playButtonClick(view: View) {
            var intent = android.content.Intent(this, PlayerSetup::class.java)

        }
    }
}
