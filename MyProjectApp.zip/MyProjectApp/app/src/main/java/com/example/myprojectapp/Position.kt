package com.example.myprojectapp


    data class Position(val row: Int, val column: Int)
